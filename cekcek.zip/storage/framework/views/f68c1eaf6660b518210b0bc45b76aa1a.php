<?php $__env->startSection('title', 'Detail Aspirasi'); ?>

<?php $__env->startSection('content'); ?>

    <div class="d-flex flex-wrap align-items-end justify-content-between gap-3 mb-4">
        <div>
            <div class="text-muted small mb-1">Detail Aspirasi</div>
            <h3 class="fw-bold mb-0"><?php echo e($inputAspirasi->judul); ?></h3>
        </div>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-outline-secondary">Kembali</a>
    </div>

    <div class="row g-4">

        
        <div class="col-lg-7">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-white fw-bold">Informasi Laporan</div>
                <div class="card-body">

                    <div class="row mb-3">
                        <div class="col-6">
                            <div class="text-muted small">Pelapor</div>
                            <div class="fw-semibold"><?php echo e($inputAspirasi->user->name ?? '-'); ?></div>
                        </div>
                        <div class="col-6">
                            <div class="text-muted small">Kategori</div>
                            <div class="fw-semibold"><?php echo e($inputAspirasi->kategori->nama_kategori ?? '-'); ?></div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-6">
                            <div class="text-muted small">Tanggal Lapor</div>
                            <div class="fw-semibold"><?php echo e($inputAspirasi->created_at->format('d M Y, H:i')); ?></div>
                        </div>
                        <div class="col-6">
                            <div class="text-muted small">Lokasi</div>
                            <div class="fw-semibold"><?php echo e($inputAspirasi->lokasi ?? '-'); ?></div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="text-muted small">Isi Laporan</div>
                        <div class="fw-normal" style="white-space: pre-line;"><?php echo e($inputAspirasi->isi_laporan); ?></div>
                    </div>

                    <div class="mb-2">
                        <div class="text-muted small mb-2">Bukti Foto</div>
                        <?php if($inputAspirasi->foto): ?>
                            <img src="<?php echo e(asset('storage/' . $inputAspirasi->foto)); ?>" class="img-fluid rounded" style="max-height: 320px;" alt="Bukti laporan">
                        <?php else: ?>
                            <div class="bg-light rounded d-flex align-items-center justify-content-center text-muted" style="height: 200px;">
                                Tidak ada foto
                            </div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>

            
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-white fw-bold">Histori Aspirasi</div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0 small">
                        <li class="mb-2">
                            <span class="fw-semibold">Dibuat</span>
                            &mdash; <?php echo e($inputAspirasi->created_at->format('d M Y, H:i')); ?>

                        </li>
                        <li>
                            <span class="fw-semibold">Terakhir diperbarui</span>
                            &mdash; <?php echo e($inputAspirasi->updated_at->format('d M Y, H:i')); ?>

                            (status saat ini: <strong><?php echo e(strtoupper($inputAspirasi->status)); ?></strong>)
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        
        <div class="col-lg-5">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-bold">Umpan Balik &amp; Status</div>
                <div class="card-body">

                    <form action="<?php echo e(route('admin.laporan.update-feedback', $inputAspirasi)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-3">
                            <label class="form-label">Status Penyelesaian</label>
                            <select name="status" class="form-select" required>
                                <option value="pending" <?php echo e($inputAspirasi->status == 'pending' ? 'selected' : ''); ?>>Menunggu</option>
                                <option value="proses" <?php echo e($inputAspirasi->status == 'proses' ? 'selected' : ''); ?>>Diproses</option>
                                <option value="selesai" <?php echo e($inputAspirasi->status == 'selesai' ? 'selected' : ''); ?>>Selesai</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Tanggapan untuk Siswa</label>
                            <textarea name="tanggapan" class="form-control" rows="6" placeholder="Tulis tanggapan atau progres perbaikan di sini..."><?php echo e(old('tanggapan', $inputAspirasi->tanggapan)); ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">Simpan Tanggapan</button>
                    </form>

                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\aspirasi_sekolah\resources\views/admin/show.blade.php ENDPATH**/ ?>