<?php $__env->startSection('title', 'Lapor'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-8">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h3 class="text-center">Laporkan</h3>
                </div>
                <div class="card-body">
                    
                    <form action="<?php echo e(route('buat-laporan')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        
                    </form>

                </div>
            </div>
        </div>


        <div class="col-4">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h3 class="text-center">Laporan</h3>
                </div>
                <div class="card-body">
                    
                </div>
            </div>
        </div>

    </div>


    

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\aspirasi_sekolah\resources\views/siswa/lapor.blade.php ENDPATH**/ ?>