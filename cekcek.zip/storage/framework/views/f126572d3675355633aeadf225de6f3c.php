<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <h3 class="fw-bold mb-4">Dashboard Aspirasi</h3>

    
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card shadow-sm text-center py-3">
                <div class="fs-4 fw-bold"><?php echo e($summary['total']); ?></div>
                <div class="text-muted small">Total Aspirasi</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card shadow-sm text-center py-3">
                <div class="fs-4 fw-bold text-secondary"><?php echo e($summary['pending']); ?></div>
                <div class="text-muted small">Menunggu</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card shadow-sm text-center py-3">
                <div class="fs-4 fw-bold text-warning"><?php echo e($summary['proses']); ?></div>
                <div class="text-muted small">Diproses</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card shadow-sm text-center py-3">
                <div class="fs-4 fw-bold text-success"><?php echo e($summary['selesai']); ?></div>
                <div class="text-muted small">Selesai</div>
            </div>
        </div>
    </div>

    
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('admin.dashboard')); ?>" method="GET" class="row g-3 align-items-end">

                <div class="col-md-2">
                    <label class="form-label small">Per Tanggal</label>
                    <input type="date" name="tanggal" class="form-control form-control-sm" value="<?php echo e(request('tanggal')); ?>">
                </div>

                <div class="col-md-2">
                    <label class="form-label small">Per Bulan</label>
                    <input type="month" name="bulan" class="form-control form-control-sm" value="<?php echo e(request('bulan')); ?>">
                </div>

                <div class="col-md-2">
                    <label class="form-label small">Per Siswa</label>
                    <input type="text" name="siswa" class="form-control form-control-sm" placeholder="Nama siswa" value="<?php echo e(request('siswa')); ?>">
                </div>

                <div class="col-md-2">
                    <label class="form-label small">Per Kategori</label>
                    <select name="kategori_id" class="form-select form-select-sm">
                        <option value="">Semua</option>
                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kategori->id); ?>" <?php echo e(request('kategori_id') == $kategori->id ? 'selected' : ''); ?>>
                                <?php echo e($kategori->nama_kategori); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="form-label small">Status</label>
                    <select name="status" class="form-select form-select-sm">
                        <option value="">Semua</option>
                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Menunggu</option>
                        <option value="proses" <?php echo e(request('status') == 'proses' ? 'selected' : ''); ?>>Proses</option>
                        <option value="selesai" <?php echo e(request('status') == 'selesai' ? 'selected' : ''); ?>>Selesai</option>
                    </select>
                </div>

                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-primary btn-sm w-100">Filter</button>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-outline-secondary btn-sm w-100">Reset</a>
                </div>

            </form>
        </div>
    </div>

    
    <div class="card shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Tanggal</th>
                        <th>Siswa</th>
                        <th>Kategori</th>
                        <th>Judul</th>
                        <th>Status</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $aspirasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $statusClass = match($item->status) {
                                'selesai' => 'bg-success-subtle text-success',
                                'proses' => 'bg-warning-subtle text-warning-emphasis',
                                default => 'bg-secondary-subtle text-secondary',
                            };
                        ?>
                        <tr>
                            <td class="small"><?php echo e($item->created_at->format('d M Y')); ?></td>
                            <td><?php echo e($item->user->name ?? '-'); ?></td>
                            <td><?php echo e($item->kategori->nama_kategori ?? '-'); ?></td>
                            <td><?php echo e($item->judul); ?></td>
                            <td>
                                <span class="badge <?php echo e($statusClass); ?>"><?php echo e(strtoupper($item->status)); ?></span>
                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(route('admin.laporan.show', $item)); ?>" class="btn btn-sm btn-outline-primary">
                                    Tanggapi
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">Belum ada data aspirasi.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($aspirasis->hasPages()): ?>
            <div class="card-footer bg-white">
                <?php echo e($aspirasis->links()); ?>

            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\aspirasi_sekolah\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>